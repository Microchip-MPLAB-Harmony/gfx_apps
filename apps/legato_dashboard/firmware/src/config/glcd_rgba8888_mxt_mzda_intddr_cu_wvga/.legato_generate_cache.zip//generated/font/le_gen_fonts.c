#include "gfx/legato/generated/le_gen_assets.h"

